### R code from vignette source 'CRISPRseek.Rnw'

###################################################
### code chunk number 1: style
###################################################
BiocStyle::latex()


###################################################
### code chunk number 2: CRISPRseek.Rnw:131-138
###################################################
library(CRISPRseek)
library(BSgenome.Hsapiens.UCSC.hg19)
library(TxDb.Hsapiens.UCSC.hg19.knownGene)
library(org.Hs.eg.db)
outputDir <- getwd()
inputFilePath <- system.file('extdata', 'inputseq.fa', package = 'CRISPRseek')
REpatternFile <- system.file('extdata', 'NEBenzymes.fa', package = 'CRISPRseek')


###################################################
### code chunk number 3: CRISPRseek.Rnw:166-172
###################################################
results <- offTargetAnalysis(inputFilePath, findgRNAsWithREcutOnly = TRUE, 
REpatternFile = REpatternFile, findPairedgRNAOnly = TRUE, 
BSgenomeName = Hsapiens, chromToSearch ="chrX", min.gap = 0, max.gap = 20,
txdb = TxDb.Hsapiens.UCSC.hg19.knownGene, orgAnn = org.Hs.egSYMBOL,
max.mismatch = 0,overlap.gRNA.positions = c(17, 18), 
outputDir = outputDir,overwrite = TRUE)


###################################################
### code chunk number 4: CRISPRseek.Rnw:185-191
###################################################
results <- offTargetAnalysis(inputFilePath, findgRNAsWithREcutOnly = FALSE,
REpatternFile = REpatternFile,findPairedgRNAOnly = TRUE, 
BSgenomeName = Hsapiens, chromToSearch = "chrX",
txdb = TxDb.Hsapiens.UCSC.hg19.knownGene,
orgAnn = org.Hs.egSYMBOL, 
max.mismatch = 1, outputDir = outputDir, overwrite = TRUE)


###################################################
### code chunk number 5: CRISPRseek.Rnw:203-209
###################################################
results <- offTargetAnalysis(inputFilePath, findgRNAsWithREcutOnly = TRUE,
REpatternFile = REpatternFile, findPairedgRNAOnly = FALSE, 
BSgenomeName = Hsapiens, chromToSearch = "chrX", 
txdb = TxDb.Hsapiens.UCSC.hg19.knownGene,
orgAnn = org.Hs.egSYMBOL,
max.mismatch = 1, outputDir = outputDir, overwrite = TRUE)


###################################################
### code chunk number 6: CRISPRseek.Rnw:222-228
###################################################
results <- offTargetAnalysis(inputFilePath, findgRNAsWithREcutOnly = FALSE,
REpatternFile = REpatternFile,findPairedgRNAOnly = FALSE, 
BSgenomeName = Hsapiens, chromToSearch = "chrX", 
txdb = TxDb.Hsapiens.UCSC.hg19.knownGene,
orgAnn = org.Hs.egSYMBOL,
max.mismatch = 1, outputDir = outputDir, overwrite = TRUE)


###################################################
### code chunk number 7: CRISPRseek.Rnw:240-249
###################################################
gRNAFilePath <- system.file('extdata', 'testHsap_GATA1_ex2_gRNA1.fa',
package = 'CRISPRseek')
results <- offTargetAnalysis(inputFilePath = gRNAFilePath, 
findgRNAsWithREcutOnly = FALSE, REpatternFile = REpatternFile,
findPairedgRNAOnly = FALSE, findgRNAs = FALSE,
BSgenomeName = Hsapiens, chromToSearch = 'chrX', 
txdb = TxDb.Hsapiens.UCSC.hg19.knownGene, 
orgAnn = org.Hs.egSYMBOL,
max.mismatch = 1, outputDir = outputDir, overwrite = TRUE)


###################################################
### code chunk number 8: CRISPRseek.Rnw:262-265
###################################################
results <- offTargetAnalysis(inputFilePath, findgRNAsWithREcutOnly = TRUE,
REpatternFile = REpatternFile,findPairedgRNAOnly = TRUE,
chromToSearch = "", outputDir = outputDir, overwrite = TRUE)


###################################################
### code chunk number 9: CRISPRseek.Rnw:285-288
###################################################
results <- offTargetAnalysis(inputFilePath, findgRNAsWithREcutOnly = TRUE,
annotateExon = FALSE,findPairedgRNAOnly = TRUE, chromToSearch = "chrX",
max.mismatch = 0, BSgenomeName = Hsapiens, outputDir = outputDir, overwrite = TRUE)


###################################################
### code chunk number 10: CRISPRseek.Rnw:295-304
###################################################
results <- offTargetAnalysis(inputFilePath, findgRNAsWithREcutOnly = TRUE,
    annotateExon = FALSE,findPairedgRNAOnly = TRUE, chromToSearch = "chrX",
    max.mismatch = 0, BSgenomeName = Hsapiens, 
    rule.set = "CRISPRscan",
    baseBeforegRNA = 6,
    baseAfterPAM = 6,
    featureWeightMatrixFile =  system.file("extdata", "Morenos-Mateo.csv",
            package = "CRISPRseek"),
    outputDir = outputDir, overwrite = TRUE)


###################################################
### code chunk number 11: CRISPRseek.Rnw:315-322
###################################################
inputFile1Path <- system.file("extdata", "rs362331C.fa",  package = "CRISPRseek")
inputFile2Path <- system.file("extdata", "rs362331T.fa",  package = "CRISPRseek") 
REpatternFile <- system.file("extdata", "NEBenzymes.fa", package = "CRISPRseek")
seqs <- compare2Sequences(inputFile1Path, inputFile2Path, 
    outputDir = outputDir , REpatternFile = REpatternFile, 
    overwrite = TRUE)
seqs


###################################################
### code chunk number 12: CRISPRseek.Rnw:343-348
###################################################
results <- offTargetAnalysis(inputFilePath, annotatePaired = FALSE, 
    chromToSearch = "chrX",
    enable.multicore = TRUE, n.cores.max = 10, annotateExon = FALSE,
    max.mismatch = 0, BSgenomeName = Hsapiens, 
    outputDir = outputDir, overwrite = TRUE)


###################################################
### code chunk number 13: CRISPRseek.Rnw:360-367
###################################################
results <- offTargetAnalysis(inputFilePath, annotatePaired = FALSE,
    scoring.method = "CFDscore",
    PAM.pattern  = "NNG$|NGN$",
    chromToSearch = "chrX",
    annotateExon = FALSE,
    max.mismatch = 2, BSgenomeName = Hsapiens,
    outputDir = outputDir, overwrite = TRUE)


###################################################
### code chunk number 14: CRISPRseek.Rnw:379-389
###################################################
offTargetAnalysis(inputFilePath, findgRNAsWithREcutOnly =  FALSE,
                 findPairedgRNAOnly = FALSE,
                 annotatePaired = FALSE,
                 BSgenomeName = Hsapiens, chromToSearch = "chrX",
                 txdb = TxDb.Hsapiens.UCSC.hg19.knownGene,
                 orgAnn = org.Hs.egSYMBOL, max.mismatch = 4,
                 outputDir = outputDir, overwrite = TRUE, PAM.location = "5prime",
                 PAM = "TGT", PAM.pattern = "^T[A|G]N", allowed.mismatch.PAM = 2,
                 subPAM.position = c(1,2), baseEditing = TRUE,
                 editingWindow = 10:20, targetBase = "A")


###################################################
### code chunk number 15: CRISPRseek.Rnw:419-437
###################################################
resultsIndelF <- offTargetAnalysis(
                 inputFilePath, findgRNAsWithREcutOnly =  FALSE,
                 findPairedgRNAOnly = FALSE,
                 annotatePaired = FALSE,
                 BSgenomeName = Hsapiens, chromToSearch = "chrX",
                 txdb = TxDb.Hsapiens.UCSC.hg19.knownGene,
                 orgAnn = org.Hs.egSYMBOL, max.mismatch = 1,
                 outputDir = outputDir, overwrite = TRUE,
                 scoring.method = "CFDscore",
                 PAM.pattern  = "NNG$|NGN$",
                 predIndelFreq = TRUE)

 if(exists("resultsIndelF")) 
 {
     print(head(resultsIndelF$indelFreq[[1]]))
     mapply(write.table, resultsIndelF$indelFreq, file=paste0(names(resultsIndelF$indelFreq), '.xls'), 
        sep = "\t", row.names = FALSE)
  }


###################################################
### code chunk number 16: CRISPRseek.Rnw:485-486
###################################################
sessionInfo()


