## Notes

This directory contains some notes on implementation details that may
be helpful for those needing to maintain or modify the corresponding
code.

  - [Protecting the BC Stack from Mutation](bcstkprot.md).

  - [Immediate Binding Values](immbnd.md).
