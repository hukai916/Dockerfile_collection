
foo <- function (x, ...) 123
